<footer>
 <div class="navbar navbar-custom">
    <div class="container">
		<p class="navbar-text">© <?php echo date('Y')." "; echo ucwords($_SERVER['SERVER_NAME']); ?>. All rights reserved </p>
     <div id="go_top"> <a href="#top_home" class="navbar-btn btn-success btn pull-right">
      <span class="glyphicon glyphicon-arrow-up"></span> Lên đầu trang</a>
    </div> </div>
    </div>
   </footer> 
<!-------------------------------------------------
Develop by Nguyễn Trung Nhẫn-----------------------
Email: trungnhan0911@yandex.com-----
--------------------------------------------------->
